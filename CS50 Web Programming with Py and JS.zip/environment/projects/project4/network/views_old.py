import json
import time
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.http import JsonResponse
from datetime import datetime
from django.utils.timezone import get_current_timezone
import pytz
from django.core.paginator import Paginator

from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt


from .models import User, Post, Likes, Following

MAXPAGEPOSTS = 10

def index(request):
    return render(request, "network/index.html")
    
def all_posts(request):
    
    page = int(request.GET.get('page'))
    
    print("Page: " + str(page))
    all_posts = Post.objects.all().order_by('-timestamp')
    paginator = Paginator(all_posts,MAXPAGEPOSTS)
    
    posts = paginator.page(page)
    data = []
    for each in posts:
            data.append({
                "db_id": each.id,
                "creator": str(User.objects.get(username=each.user)),
                "text": each.text,
                "timestamp": each.timestamp,
                "likes": Likes.objects.filter(post=each).count(),
                "liked" : Likes.objects.filter(post=each).filter(user=request.user).count(),
                "owner": (request.user == User.objects.get(username=each.user))
            })
    
    
    print(data)
    # Return list of posts
    return JsonResponse({
        "posts": data
    })
    
    
@csrf_exempt
@login_required
def profile(request,creator):
    print("Openning user: " + creator)
    user = User.objects.get(username=creator)
    email = user.email
    following = Following.objects.filter(user=user).count()
    followers = Following.objects.filter(user_followed = user).count()
    # Users profile page
    count_posts = Post.objects.filter(user=user).count()
    
    if(count_posts > MAXPAGEPOSTS):
        pagination = True
    else:
        pagination = False
    
    return render(request, "network/profile.html",{
                "user": user,
                "email": email, 
                "following": following,
                "followers": followers,
                "pagination": pagination
                })
@csrf_exempt
@login_required             
def profile_posts(request):
    
    page = int(request.GET.get('page'))
    
    print("Page: " + str(page))
    all_posts = Post.objects.all().order_by('-timestamp').filter(user=request.user)
    paginator = Paginator(all_posts,MAXPAGEPOSTS)
    
    posts = paginator.page(page)
    data = []
    for each in posts:
            data.append({
                "db_id": each.id,
                "creator": str(User.objects.get(username=each.user)),
                "text": each.text,
                "timestamp": each.timestamp,
                "likes": Likes.objects.filter(post=each).count(),
                "liked" : Likes.objects.filter(post=each).filter(user=request.user).count(),
                "owner": (request.user == User.objects.get(username=each.user))
            })


    return JsonResponse({
        "posts": data
    })
    
    

    
@csrf_exempt
@login_required
def post(request):
    data = json.loads(request.body)
    text = data.get("post_text")
    db_id = data.get("post_id")

    if len(text)>400:
        return JsonResponse({
            "error": "Too many characters - " + str(len(text))
        }, status=400)
        
    print("DB Result:" + str(db_id))
    if(db_id):
        print("post to be updated")
        post = Post.objects.get(pk=db_id)
        post.text = text
        if(post.user == request.user):
            post.timestamp = datetime.now(tz=get_current_timezone())
            post.user = request.user
        else:
            return JsonResponse({"error": "Wrong User"}, status=403)
    else:
        post = Post.objects.create(
            user=request.user,
            text=text,
            )
    post.save()

    data.append({
            "db_id": post.id,
            "creator": str(User.objects.get(username=post.user)),
            "text": post.text,
            "timestamp": post.timestamp,
            "likes": Likes.objects.filter(post=post).count(),
            "owner": (request.user == User.objects.get(username=post.user))
        })
    
    
    return JsonResponse({"message": "Post uploaded successfully.","post":post}, status=201)

@csrf_exempt
@login_required
def like(request):
    
    if request.method == 'POST':
        data = json.loads(request.body)
        post = Post.objects.get(pk=data.get("post_id"))
        
        Likes.objects.create(
            user = request.user,
            post = post)
        
        count = post.liked.all().count()
    
        return JsonResponse({"message": "Like saved successfully.","count":count}, status=201)
        
        
    
@csrf_exempt
@login_required
def dislike(request):
    
    if request.method == 'POST':
        data = json.loads(request.body)
        post = Post.objects.get(pk=data.get("post_id"))    
        Likes.objects.filter(post=post).filter(user=request.user).delete()
        
        count = post.liked.all().count()
        return JsonResponse({"message": "Dislike saved successfully.","count":count}, status=201)
        
        
    
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "network/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "network/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "network/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "network/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "network/register.html")
