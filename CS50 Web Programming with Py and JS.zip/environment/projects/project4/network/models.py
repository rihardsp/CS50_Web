from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    pass


        
class Post(models.Model):
    user = models.ForeignKey("User", on_delete=models.CASCADE, related_name="emails")
    text = models.CharField(max_length=400)
    timestamp = models.DateTimeField(auto_now_add=True)
    
    
class Likes(models.Model):
    user = models.ForeignKey("User", on_delete=models.CASCADE, related_name="like")
    post = models.ForeignKey("Post", on_delete=models.CASCADE, related_name="liked")
    
    def __str__(self):
        return f'{self.user} likes {self.post}.'
    
class Following(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="following")
    user_followed = models.ForeignKey(User, on_delete=models.CASCADE, related_name="followers")
    
    def __str__(self):
        return f'{self.user} follows {self.user_followed}.'