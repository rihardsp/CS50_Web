
from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("profile/<str:profile_owner>", views.profile, name="profile"),
    path("following", views.following, name="following"),
    
    #API Paths
    path("post", views.post, name="newpost"),
    path("like", views.like, name= "like"),
    path("dislike", views.dislike, name= "dislike"),
    path("follow", views.follow, name= "follow"),
    path("unfollow", views.unfollow, name= "unfollow")
]
