import json
import time
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.http import JsonResponse
from datetime import datetime
from django.utils.timezone import get_current_timezone
import pytz
from django.core.paginator import Paginator

from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt


from .models import User, Post, Likes, Following

MAXPAGEPOSTS = 10

def index(request):
    
    """ Main index function loaded every time user opens website"""
    page_posts = get_posts(request,user_filter=None, profile_links=True)
    current_user = request.user
    return render(request, "network/all_posts.html", {
        'page_obj': page_posts,
        "current_user":current_user
    })
    

  
    
@csrf_exempt
@login_required
def profile(request,profile_owner):
    
    """ Profile site accepts two arguments request and profile_owner. 
    
    path("profile/<str:profile_owner>", views.profile, name="profile"), 
    
    """
    
    profile_owner_user = User.objects.get(username=profile_owner)
    current_user = request.user
    email = profile_owner_user.email
    following = Following.objects.filter(user=profile_owner_user).count()
    followers = Following.objects.filter(user_followed = profile_owner_user).count()
    # Users profile page
    user_id = User.objects.get(username=profile_owner).id
    current_user_id = User.objects.get(username=current_user).id
    
    page_posts = get_posts(request,user_id,False)
    user_following = Following.objects.filter(user=current_user).filter(user_followed=profile_owner_user).count()
    
    print("User Following:" + str(user_following))
    
    return render(request, "network/profile.html",{
                "profile_owner_user": profile_owner_user,
                "email": email, 
                "user_id":user_id,
                "following": following,
                "followers": followers,
                "page_obj": page_posts,
                "current_user_id": current_user_id,
                "current_user":current_user,
                "user_following": user_following
                })

def following(request):
    
    
    """ Following page displays all users that the main user follows.ArithmeticError
    
    path("following", views.following, name="following")
    """
    
    current_user = request.user
    followed_users = Following.objects.filter(user=current_user)
    following = Following.objects.filter(user=current_user).count()
    
    all_posts_obj = []
    for user in followed_users:
        users_posts = Post.objects.all().filter(user=user.user_followed).order_by('-timestamp')
        for each in users_posts:
            all_posts_obj.append(each)

    page_posts = get_posts(request,user_filter=None,readydata=all_posts_obj,profile_links=True)   


    
    return render(request, "network/following.html",{
        "page_obj": page_posts,
        "current_user":current_user,
        "following": following
    })
    

@csrf_exempt
@login_required
def get_posts(request,user_filter,profile_links=False,readydata=False):
    
    """ Dynamic get_posts function that takes in request and generates posts, than applies filters to those posts
    
    Parameters
        ----------
        request : request object, mandatory
            Request received from the client
        user_filter: int, optional
            user id for the posts to be filtered on (default is None)
        profile_links: bool, optional
            whether to add profile links to each post (default is False)
        readydata: list, optional
            pass in already created list of dictionaries (default is False)
    """
    
    page = int(request.GET.get('page') or 1)
    
    if(user_filter == None and readydata == False):
        print("Default")
        all_posts = Post.objects.all().order_by('-timestamp')
    elif(readydata != False):
        print("Data is ready")
        all_posts = readydata
    else:
        ("User Filter needed")
        all_posts = Post.objects.all().filter(user=user_filter)
    

    data = []
    for each in all_posts:
        data.append({
            "id": each.id,
            "creator": str(User.objects.get(username=each.user)),
            "creator_id" : User.objects.get(username=each.user).id,
            "text": each.text,
            "timestamp": each.timestamp,
            "likes": Likes.objects.filter(post=each).count(),
            "liked" : Likes.objects.filter(post=each).filter(user=request.user).count(),
            "owner": (request.user == User.objects.get(username=each.user)),
            "profile_links" : profile_links
        })
    
    from operator import itemgetter
    data = sorted(data, key=itemgetter('timestamp'), reverse=True)
    
    paginator = Paginator(data,MAXPAGEPOSTS)
   
    page_posts = paginator.page(page)
 
    return page_posts
    

    
@csrf_exempt
@login_required
def post(request):
    
    """
    Saves post from client API POST request
    
    path("post", views.post, name="newpost")
    
    Parameters
        ----------
        request : request, mandatory
        data: 
            data["post_text"] : str, mandatory
                post text passed to API
            data["post_id"] : int, optional
                if post needs to be updated - db_id of that post. (default value - None)
    
    """
    if request.method == 'POST':
        data = json.loads(request.body)
        text = data.get("post_text")
        db_id = data.get("post_id")
    
        if len(text)>400:
            return JsonResponse({
                "error": "Too many characters - " + str(len(text))
            }, status=400)
            
    
        if(db_id):
            print("post to be updated")
            post = Post.objects.get(pk=db_id)
            post.text = text
            if(post.user == request.user):
                post.timestamp = datetime.now(tz=get_current_timezone())
                post.user = request.user
            else:
                return JsonResponse({"error": "Wrong User"}, status=403)
        else:
            post = Post.objects.create(
                user=request.user,
                text=text,
                )
        post.save()
    
        data = [{
                "db_id": post.id,
                "creator": str(User.objects.get(username=post.user)),
                "text": post.text,
                "timestamp": post.timestamp,
                "likes": Likes.objects.filter(post=post).count(),
                "owner": (request.user == User.objects.get(username=post.user))
            }]
        
        
        return JsonResponse({"message": "Post uploaded successfully.","post":data}, status=201)

@csrf_exempt
@login_required
def like(request):
    """
    Saves users liked posts
    
    path("like", views.like, name= "like"),
    
    Parameters
        ----------
        request : request, mandatory
        data:
            data["post_id"] : int, mandatory
                id of the post to be liked
    """
    if request.method == 'POST':
        data = json.loads(request.body)
        post = Post.objects.get(pk=data.get("post_id"))
        
        Likes.objects.create(
            user = request.user,
            post = post)
        
        count = post.liked.all().count()
    
        return JsonResponse({"message": "Like saved successfully.","count":count}, status=201)
        
        
    
@csrf_exempt
@login_required
def dislike(request):
    """
    Deletes users disliked posts
    
    path("dislike", views.dislike, name= "dislike"),
    
    Parameters
        ----------
        request : request, mandatory
        data:
            data["post_id"] : int, mandatory
                id of the post to be disliked
    """
    
    if request.method == 'POST':
        data = json.loads(request.body)
        post = Post.objects.get(pk=data.get("post_id"))    
        Likes.objects.filter(post=post).filter(user=request.user).delete()
        
        count = post.liked.all().count()
        return JsonResponse({"message": "Dislike saved successfully.","count":count}, status=201)
        
 
@csrf_exempt
@login_required
def follow(request):
    """
    Saves users who current_user follows
    
    path("follow", views.follow, name= "follow"),
    
    Parameters
        ----------
        request : request, mandatory
        data:
            data["user_id"] : int, mandatory
                user_id of the user followed
    """
    
    
    if request.method == 'POST':
        data = json.loads(request.body)
        user_followed = User.objects.get(pk=data.get("user_id"))
        
        Following.objects.create(
            user = request.user,
            user_followed = user_followed)
        
        print(user_followed)
        
        count = user_followed.followers.all().count()
        print(count)
        return JsonResponse({"message": "Like saved successfully.","count":count}, status=201)
        
        
    
@csrf_exempt
@login_required
def unfollow(request):
    """
    Deletes users who current_user unfollows
    
    path("unfollow", views.unfollow, name= "unfollow")
    
    Parameters
        ----------
        request : request, mandatory
        data:
            data["user_id"] : int, mandatory
                user_id of the user unfollowed
    """
    if request.method == 'POST':
        data = json.loads(request.body)
        user_followed = User.objects.get(pk=data.get("user_id"))  
        
        Following.objects.filter(user_followed=user_followed).filter(user=request.user).delete()
        
        count = user_followed.followers.all().count()
        
        return JsonResponse({"message": "Dislike saved successfully.","count":count}, status=201)
 
 
 
    
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "network/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "network/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "network/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "network/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "network/register.html")
