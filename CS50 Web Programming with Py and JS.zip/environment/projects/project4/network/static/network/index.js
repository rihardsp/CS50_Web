document.addEventListener('DOMContentLoaded', function() {
  

    /**
    *  Main Eventlistener function
    */
    try
    {
    document.querySelector('#compose-newpost').addEventListener('input', () => monitornewpost());
    document.querySelector('#submit-newpost').addEventListener('click', () => submitpost());  
    }
    catch
    {
        console.log("No QuerySelectors Found");
    }
    
    document.addEventListener('click',function(e){

    if(e.target && e.target.id.substring(0,10) == 'clickedit_'){
          let db_id = e.target.id.substring(10);
          editpost(db_id);
     }
  
    
    if(e.target && e.target.id.substring(0,10) == 'clicksave_'){
        let db_id = e.target.id.substring(10);
        savepost(db_id);
     }
     
    
    if(e.target && e.target.id.substring(0,12) == 'like_button-'){
        let db_id = e.target.id.substring(12);
        likepost(db_id);
     }
     
     if(e.target && e.target.id.substring(0,15) == 'dislike_button-'){
         let db_id = e.target.id.substring(15);
         dislikepost(db_id);
     }
     
    if(e.target && e.target.id.substring(0,9) == 'unfollow_'){
          let db_id = e.target.id.substring(9);
          unfollow(db_id);
    }
    
    if(e.target && e.target.id.substring(0,7) == 'follow_'){
          let db_id = e.target.id.substring(7);
          follow(db_id);
    }
     
   });
});


function monitornewpost(id)
{    
    /**
    * Monitor user inputs into NEW POST/EDIT POST Field. Mark it read if character limit exceeded
    * @param  {Number} id post ID if edited 
    */
    
        let textelem = 'compose-newpost';
        let charleft = 'charleft';
        let characterparagraph = 'characterparagraph';
    
    if(id)
    {
        textelem = 'edit_post-'+ id;
        charleft = 'charleft-' + id;
        characterparagraph = 'characterparagraph-' + id;
        
    }

    let textlen = document.getElementById(textelem).value.length;
    document.getElementById(charleft).innerHTML = textlen;
    
    
    
    if(textlen>400)
    {
        console.log("Character Limit reached");
        
        document.getElementById(characterparagraph).style.background = 'red';
    }
    else
    {
        document.getElementById(characterparagraph).style.background  = '';
    }
}

function submitpost(element,id)
{
    
    /**
    * Submit post (save it to database)
    * @param  {String} Edited/New post textarea element
    * @param  {Number} ID of edited post
    */
    
    let postele = element || 'compose-newpost';
    console.log("Submit Post: " + postele);

    const text = document.getElementById(postele).value;
    
    fetch('/post', {
        method: 'POST',
        body: JSON.stringify({
        post_text: text,
        post_id: id
        })
    })
    .then(response => response.json())
        .then(result => {
        // Print result and check it's valid
        console.log(result);
            if(result['error'])
            {
                console.log(result['error']);
                window.alert(result['error'])
            }
            else
            {
                console.log('API succesful');
                document.querySelector('#compose-newpost').value = '';
                console.log("Adding post to the page");
                add_post(result["post"][0],"prepend");
            }
        });
}



function add_post(contents,append="append") {

    /**
    * Add post/s to the site
    * @param  {Object} contents Post contents
    * @param  {String} append Which side of the Posts DIV post should be added beginning OR end
    */
    
    console.log("post received: " + contents);
    let editbutton = '';
    let savebutton = '';
    let likebutton = '';
    
    if(contents.owner)
    {   
        editbutton = `<a id="${"clickedit_" + contents.db_id}" class="btn btn-primary">Edit</a>`;
        savebutton = `<a id="${"clicksave_" + contents.db_id}" class="btn btn-primary">Save</a>`;
    }
    
    if(contents.liked > 0)
    {   
        likebutton = `<a class="btn btn-primary" id="dislike_button-${contents.db_id}">thumb_down_off_alt</a>`;
    }
    else
    {
        
        likebutton = `<a class="btn btn-primary" id="like_button-${contents.db_id}">thumb_up_off_alt</a>`;
        
    }
    
    // build HTML Element using content Object
    const post = document.createElement('div');
    post.className = 'post';
    post.innerHTML = `
        <div id="main_card-${contents.db_id}" class="card" style="width:95%; left:3%">
            <div id="text_card-${contents.db_id}" class="card-body">
                <h5 class="card-title"><a style="color:black;" href="profile/${contents.creator}">${contents.creator}</a></h5>
                <p id="text_field-${contents.db_id}" class="card-text">${contents.text}</p>
                <p class="card-text"><small class="text-muted">${contents.timestamp}</small></p>
                <p id="likecount-${contents.db_id}" class="card-text">${contents.likes}</p>
                <span id="likebutton-${contents.db_id}" class="material-icons">${likebutton}</span>
                ${editbutton}
            </div>
            <div id="entry_card-${contents.db_id}" style="display:none" class="card-body">
                <textarea id="edit_post-${contents.db_id}" class="form-control">${contents.text}</textarea>
                <p class="card-text" id="characterparagraph-${contents.db_id}" style="position:absolute;right:30px"><small id="charleft-${contents.db_id}" class="text-muted">0</small><small id="charmax" class="text-muted">/400</small></p>
                <br>
                ${savebutton}
            </div>
        </div>
        <br>`;
      
        
    
    // Add post to DOM
    if(append === "prepend")
    {
       
        document.querySelector('#posts').prepend(post);
    }
    else if(append === "append") 
    {   
     
        document.querySelector('#posts').append(post);
    }
    else
    {
        console.log("No direction supplied -> " + append);
    }

}

function editpost(db_id)
{   
    
    let text_cardID = "text_card-"+ db_id;
    let entry_cardID = "entry_card-" + db_id;
    let edit_post = "edit_post-" + db_id;
    
    document.getElementById(text_cardID).style.display = "none";
    document.getElementById(entry_cardID).style.display = "block";
    document.getElementById(edit_post).addEventListener('input', () => monitornewpost(db_id));

    let textlen = document.getElementById('edit_post-'+ db_id).value.length;
    document.getElementById('charleft-' + db_id).innerHTML = textlen;
}

function savepost(db_id)
{
    let text_cardID = "text_card-"+ db_id;
    let entry_cardID = "entry_card-" + db_id;
    let edit_post = "edit_post-" + db_id;
    
    document.getElementById(text_cardID).style.display = "block";
    document.getElementById(entry_cardID).style.display = "none";
    submitpost(edit_post,db_id);
    
    let maincard = "main_card-" + db_id;
    document.getElementById(maincard).remove();
}

function likepost(db_id)
{
    
    fetch('/like', {
        method: 'POST',
        body: JSON.stringify({
        post_id: db_id
        })
    }).then(response => response.json())
    .then(data => {
        let buttonID = "likebutton-"+ db_id;
        let likecountID = "likecount-"+ db_id;
        
        document.getElementById(buttonID).innerHTML = `<a class="btn btn-primary" id="dislike_button-${db_id}">thumb_down_off_alt</a>`;
        document.getElementById(likecountID).innerHTML = data["count"];
    });
}




function dislikepost(db_id)
{
    fetch('/dislike', {
        method: 'POST',
        body: JSON.stringify({
        post_id: db_id
        })
    }).then(response => response.json())
    .then(data => {
        let buttonID = "likebutton-"+ db_id;
        let likecountID = "likecount-"+ db_id;
        document.getElementById(buttonID).innerHTML = `<a class="btn btn-primary" id="like_button-${db_id}">thumb_up_off_alt</a>`;
        document.getElementById(likecountID).innerHTML = data["count"];
    });
    
   
}


function unfollow(db_id)
{
    fetch('/unfollow', {
        method: 'POST',
        body: JSON.stringify({
        user_id: db_id
        })
    }).then(response => response.json())
    .then(data => {
        document.getElementById("followOptions").innerHTML = `<a id="follow_${db_id}" class="btn btn-primary">Follow</a>`
        document.getElementById("followercount").innerHTML = data["count"]
        
    });
}

function follow(db_id)
{
    fetch('/follow', {
        method: 'POST',
        body: JSON.stringify({
        user_id: db_id
        })
        }).then(response => response.json())
        .then(data => {
        document.getElementById("followOptions").innerHTML = `<a id="unfollow_${db_id}" class="btn btn-primary">Unfollow</a>`
        document.getElementById("followercount").innerHTML = data["count"]
        
    });
}