from django.contrib import admin

# Register your models here.
from .models import Auction_Listing, Auction_Bid,Auction_Comment,Auction_Category
from .models import Watchlist_status,User


admin.site.register(Auction_Listing)
admin.site.register(Auction_Bid)
admin.site.register(Auction_Comment)
admin.site.register(Auction_Category)
admin.site.register(User)
admin.site.register(Watchlist_status)
