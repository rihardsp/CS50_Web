from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django import forms
from django.core.exceptions import ValidationError

from .models import Auction_Listing, Auction_Bid,Auction_Comment,Auction_Category,Watchlist_status
from .models import User

# All Functions cand define Message variable and pass it to page to be displayed as an alert 

def index(request):
    
    # show all listings when index page opened
    all_listings = Auction_Listing.objects.all().order_by('-created_timestamp')
    
    return render(request, "auctions/index.html", {
        'all_listings' : all_listings
    })



def login_view(request):
    
    # POST submitted - login, else render login screen
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    
    else:
        return render(request, "auctions/login.html")



def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    
    # If POST Request from form recieved, create a new user, else render register page
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")

@login_required
def create(request):
    message = False
    # If POST form recieved - create a new listing  and than render page if not just render page. 
    
    if request.method == "POST":
        # Retreive form from the page and get current user
        form = CreateNewListing(request.POST)
        user = User.objects.get(username=request.user)

        # Need to check if form is valid (server-Side) and than create a new listing 
        if form.is_valid():
            new_listing = Auction_Listing(
            listing = form.cleaned_data["listing"],
            price = form.cleaned_data["price"],
            description = form.cleaned_data["description"],
            category = form.cleaned_data["category"],
            image_url = form.cleaned_data["image_url"],
            listing_owner = user
            ) 
  
            new_listing.save()
            # Success Alert
            message = "Listing created succesfully!"
            
        else:
            # Failure Alert
            message = "Listing failed to create - check your IMG link..."

    return render(request,"auctions/create.html",{
            'form': CreateNewListing(),
            'message': message
        })
            
@login_required
def openlisting(request, listing_id):
    
    # Define variables used throughout the function
    message = False
    this_listing = Auction_Listing.objects.get(pk=listing_id)
    user = User.objects.get(username=request.user)
    owner = user.username == this_listing.listing_owner.username
    winner = user.username == this_listing.winner
    comments = this_listing.comments.all().order_by('id').reverse()
    watchlist_status = user.watchlist.filter(listing= this_listing)
    bid_form  = BidForItem()
   
    # If any of the forms on the page submitted take action, else just render this_listing. Depending on which button clicked, trigger different functionality
    if request.method == "POST":
        print("POST Received")
        
        button = request.POST.get("button")
        
        # Watchlist functionality to add listing to watchlist table by user. 
        if button == "Watchlist_add": 
            if not user.watchlist.filter(listing= this_listing):
                watchlist = Watchlist_status()
                watchlist.user = user
                watchlist.listing = this_listing
                watchlist.save()
              
        elif button == "Watchlist_remove":
            user.watchlist.filter(listing=this_listing).delete()
        
        
        
        # Submit Bid functionality - 1. check for owner, 2. check for price, 3. Save form
        if button == "Submit_Bid":
            
            # Check for owner =! user
            if owner: 
                message = "You can not bid for your own item"
            else:
                new_bid = float(request.POST["bid"])
                # Check the bid is larger than current price
                if new_bid <= this_listing.price:
                    message = "Invalid Bid Amount"
                else:    
                    form = BidForItem(request.POST)
                    # Check the form is valid and process it
                    if not form.is_valid():
                        message = "Submission failed to load. Please try again. Check your IMG link"
                    else:
                        bid = Auction_Bid.objects.create(user=user, price=new_bid)
                        this_listing.bids.add(bid)
                        this_listing.price = new_bid
                        this_listing.winner = bid
                        this_listing.save()
                        message = "Bid submitted succesfully"
                
               
        # Submit Comments via Post_Comment method        
        if button == "Post_Comment":
            comment_input = request.POST["commentblock"]
            print("Post Commennt Received")
            comment = Auction_Comment.objects.create(user=user,comment_text = comment_input)
            this_listing.comments.add(comment)
            this_listing.save()
        
        # Close Auction if Close_auction button pressed
        if request.POST.get("button") == "Close_Auction": 
            if owner:
                this_listing.closed = True
                this_listing.save()
                    
 
    # Main render stuff
    
    print("Opening listing: ", listing_id)

    return render(request, "auctions/listing.html",{
        'listing' : this_listing,
        'bid_form' : bid_form,
        'watchlist_status' : watchlist_status,
        'message' : message,
        'winner': winner,
        'owner': owner,
        'comments': comments
    })
        
    
def categories(request):
    
    # Show categories and have dynamic active functions
    all_categories = Auction_Category.objects.all()
    all_listings = Auction_Listing.objects.all().order_by('-created_timestamp')
    active = ""
    
    if request.method == "POST":
        active = request.POST.get("button")
        print(active)
        category_id = Auction_Category.objects.get(category_name=active)
        print(category_id)
        all_listings = Auction_Listing.objects.filter(category=category_id)
   
    
    return render(request, "auctions/categories.html",{
        'categories':all_categories,
        'active':active,
        'all_listings': all_listings
    })

@login_required    
def watchlist(request):
    
    # Similar to index function to display all listings
    user = User.objects.get(username=request.user)

    if request.method == "POST":
        print("POST Received")
        
        button = request.POST.get("button")
        print(button)
        this_listing = this_listing = Auction_Listing.objects.get(pk=button)
        user.watchlist.filter(listing=this_listing).delete()

        
    return render(request, "auctions/watchlist.html",{
        'all_listings' : user.watchlist.all()
    })



class CreateNewListing(forms.Form):
    listing = forms.CharField(max_length=200, label="Listing Name")
    description = forms.CharField(max_length=2000, label="Please describe your product")
    price = forms.DecimalField(min_value=0.05,decimal_places=2,max_digits=10,label="Please enter your starting bid")
    category = forms.ModelChoiceField(queryset=Auction_Category.objects.all())
    image_url = forms.URLField(required=False)
    
class BidForItem(forms.Form):
    bid = forms.DecimalField(min_value=0.05,decimal_places=2,max_digits=10)
  
