from django.contrib.auth.models import AbstractUser
from django.db import models
import random


class User(AbstractUser):
    pass

class Auction_Category(models.Model):
    category_name = models.CharField(max_length=100)
    
    def __str__(self):
        return self.category_name
        
        
class Auction_Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_comments")
    comment_text = models.TextField()
    time = models.DateTimeField(auto_now_add=True, blank=True)

    def __str__(self):
        return f"User: {self.user}, Comment: {self.comment_text}"

class Auction_Bid(models.Model):
    time = models.DateTimeField(auto_now_add=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_bids")
    price = models.DecimalField(max_digits=10, decimal_places=2)
    
    def __str__(self):
        return f"User: {self.user}, Bid: {self.price}"
        
class Auction_Listing(models.Model):
    listing = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    bids = models.ManyToManyField(Auction_Bid, blank=True, related_name="bids")
    description = models.CharField(max_length=2000)
    category = models.ForeignKey(Auction_Category, on_delete=models.CASCADE)
    image_url = models.CharField(max_length=2000,blank=True, null=True)
    created_timestamp = models.DateTimeField(auto_now_add=True, blank=True)
    listing_owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="owners")
    comments = models.ManyToManyField(Auction_Comment, blank=True, related_name="comments")
    closed = models.BooleanField(default=False)
    winner = models.ForeignKey(Auction_Bid, on_delete=models.CASCADE, related_name='last_bid', blank=True, null=True)
    
    def __str__(self):
        return f"Name: {self.listing}, Time: {self.created_timestamp}"
        

    
class Watchlist_status(models.Model):
    listing = models.ForeignKey(Auction_Listing, on_delete=models.CASCADE, related_name="listings")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="watchlist")
    
    def __str__(self):
       return f"Usr: {self.user}, Listing: {self.listing}"



