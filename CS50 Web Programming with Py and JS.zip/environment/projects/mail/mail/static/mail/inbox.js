

document.addEventListener('DOMContentLoaded', function() {
  
  // Use buttons to toggle between views
  document.querySelector('#inbox').addEventListener('click', () => load_mailbox('inbox'));
  document.querySelector('#sent').addEventListener('click', () => load_mailbox('sent'));
  document.querySelector('#archived').addEventListener('click', () => load_mailbox('archive'));
  document.querySelector('#compose').addEventListener('click', compose_email);
  document.querySelector('#close_email').addEventListener('click', () => load_mailbox('inbox'));
  document.querySelector('#compose-form').addEventListener('submit', send_email);

  // By default, load the inbox
  load_mailbox('inbox');
});

function compose_email(empty,subject,recipients,body,timestamp) {

  // default if parametrs empty - ''
  subject = subject || '';
  recipients = recipients || '';
  body = body || '';
  
  
  // check that this is not a first response email
  if(subject.indexOf("Re") == -1 && subject != '')
  {
    subject = "Re: " + subject;
  }
  
  if(body != '')
  {
    body = "\n\n\n\n\n" + "On "+ timestamp + " " + recipients + " wrote: \n\n" +body
  }
  
  
  // Show compose view and hide other views
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#compose-view').style.display = 'block';
  document.querySelector('#open_email-view').style.display = 'none';
  
  // Populate composition fields with either '' or reply placeholders
  document.querySelector('#compose-recipients').value = recipients;
  document.querySelector('#compose-subject').value = subject;
  document.querySelector('#compose-body').value = body;
}

function send_email() {
  
  //to stop from refreshing website and submitting the form
  event.preventDefault();
  
  // get form values
  const in_recipients = document.querySelector('#compose-recipients').value;
  const in_subject = document.querySelector('#compose-subject').value;
  const in_body = document.querySelector('#compose-body').value;
  
  
  // post values to server from form
   fetch('/emails', {
    method: 'POST',
    body: JSON.stringify({
        recipients: in_recipients,
        subject: in_subject,
        body: in_body
    })
  })
  .then(response => response.json())
  .then(result => {
      // Print result and check it's valid
      console.log(result);
      if(result['error'])
      {
        let text = "Warning!\n\n" + result['error']
        window.alert(text);
      }
      else
      {
        let text =  result['message']
        window.alert(text);
        // If Successful return to imbox
        load_mailbox('sent');
      }
  });

}

function load_mailbox(mailbox) {
  
  // Clear Emails View - not sure this one actually works. 
  document.querySelector('#emails-view').innerHTML = '';
  
  // Show the mailbox and hide other views
  document.querySelector('#emails-view').style.display = 'block';
  document.querySelector('#compose-view').style.display = 'none';
  document.querySelector('#open_email-view').style.display = 'none';

  // Show the mailbox name
  const view = document.querySelector('#emails-view')
  view.innerHTML  = `<h3>${mailbox.charAt(0).toUpperCase() + mailbox.slice(1)}</h3>`;
  
  
  // render all emails from the server / mailbox
  let fetchstring = '/emails/'+mailbox;
  fetch(fetchstring)
  .then(response => response.json())
  .then(emails => {

      renderEmails(emails,view,mailbox);

  });
}

function renderEmails(emails,view,mailbox){
  
  // removes previous junk from the website so we can start with an empty div
  if( view.childNodes.length != 1)
  {
    view.removeChild(view.childNodes.item(1));
  }

  // build a nice table with all emails based on type of emails inbox/sent
  const table  = document.createElement('table');
  table.className = 'table table-hover';
  const headings = document.createElement('tr');
  if(mailbox == 'sent')
  {
    headings.innerHTML = `
    <th scope="col"> To </th>
    <th scope="col"> Subject </th>
    <th scope="col"> Time </th>
    `;
  }
  else
  {
    headings.innerHTML = `
    <th scope="col"> From </th>
    <th scope="col"> Subject </th>
    <th scope="col"> Time </th>
    `;
  }

  // add headings 
  table.appendChild(headings);
  
  // loop through all emails reuturned by fetch and create row per email. Also take into account inbox/sent
  for (let i = 0; i < emails.length; i++)
  {
    let firstColumn = emails[i]['sender'];
    if(mailbox == 'sent')
    {
      firstColumn = emails[i]['recipients'];
    }
    
    let tr = document.createElement('tr');
    tr.innerHTML = `
      <td> ${firstColumn} </td>
      <td> ${emails[i]['subject']} </td>
      <td> ${emails[i]['timestamp']}</td>
      `;
    if(emails[i]['read'] == false)
    {
       tr.className = "table-active"; 
    }
    tr.style = 'cursor:pointer;';
    
    // each row is clickable - leads to view email
    tr.addEventListener('click', () => view_email(emails[i]['id'],mailbox));
   
    table.appendChild(tr);
  }
  
  view.appendChild(table);
}




function view_email(email_id,mailbox){
  
  // again clear the emails-view div, not sure this actually works 
  document.querySelector('#emails-view').innerHTML = '';
  
  // hide rest of the page
  document.querySelector('#compose-view').style.display = 'none';
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#open_email-view').style.display = 'block';

  
  //change read status in the server
  let fetchstring = '/emails/'+email_id; 
  fetch(fetchstring, {
    method: 'PUT',
    body: JSON.stringify({
        read: true
    })
  });
  
  // fetch email itself from the server
  fetch(fetchstring)
  .then(response => response.json())
  .then(email => {
    
      document.querySelector('#emailsubject').innerHTML = email['subject'];
      document.querySelector('#emailinfo').innerHTML = 'From: ' + email['sender'] + 
      '<br> To: '+ email['recipients'] + 
      '<br> Date: ' + email['timestamp'];
      document.querySelector('#emailbody').innerHTML = email['body'];
      
      // based on type of archived status add archived or unarchived button
      if(email['archived'])
      {
        document.querySelector('#archive_email').innerHTML = 'Unarchive';
        document.querySelector('#archive_email').addEventListener('click', () => archiving(email_id,false));
          
      }
      else
      {
        document.querySelector('#archive_email').innerHTML = 'Archive';
        document.querySelector('#archive_email').addEventListener('click', () => archiving(email_id,true));
      }
      
      
      // button to replay. send back to compose email, but with replay paramaters
      document.querySelector('#reply_email').addEventListener('click', () => {
          compose_email('reply',email['subject'],email['sender'],email['body'],email['timestamp'])});
  });

  
}



function archiving(email_id,action)
{
  // update email archived status based on action and reload inbox
  let fetchstring = '/emails/'+email_id; 
  fetch(fetchstring, {
  method: 'PUT',
  body: JSON.stringify({
      archived: action
    })
  }).then(load_mailbox('inbox'));
}

