#Tax 

Tax Is something you pay to government