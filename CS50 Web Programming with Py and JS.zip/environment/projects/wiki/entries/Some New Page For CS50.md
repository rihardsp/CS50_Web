

#Some New Page For CS50 

# WHY DOES MY PAGE JUMPS AROUND WHEN TYPING???

I EXHAUSTED CSS, GOOOGLE AND EVERYTHING ELSE............

Will ask colleague in work..