from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path('wiki/<str:title>',views.entry,name="entry"),
    path('search',views.query,name="search"),
    path('new',views.new,name="new"),
    path('wiki/<str:title>/editing', views.to_edit, name="to_edit"),
    path('edited',views.save_edit,name="edited"),
    path('random',views.random_page,name="random")
]
