from django.shortcuts import render
from django.http import HttpResponse
from markdown2 import Markdown
from django import forms

markdowner = Markdown()

from . import util
import random 

def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })

def entry(request,title):
    print("Entry Received... " + str(title))
  

    return load_page(request,title)
        

def query(request):
    question = request.GET.get('q','')
    print("Search Received... /n Search: " + str(question))
    
    content = util.get_entry(question)
   
    if content is not None:
        return load_page(request,question,content)
    else:
        search_entries = []
        all_entries = util.list_entries()
        
        print(str(all_entries))
        
        for each in all_entries:
            
            print("Working on " + str(each))
            
            if question in str(each):
                search_entries.append(each)
                
        return render(request, "encyclopedia/index.html", {
            "entries": search_entries,
            "question":question,
            "substring_search":True
        })
    
    
            
def new(request):
    
    # Check if method is POST
    if request.method == "POST":
        
        # Get the data the user submitted 
        form = NewWikiForm(request.POST)
        
        # Need to check if form is valid (server-Side)
        if form.is_valid():
            
            # Get the data
            title = form.cleaned_data["title"]
            textarea = form.cleaned_data["textarea"]
            
            if not util.get_entry(title):
                return save_form(request,form,title,textarea)
                
            else:
                print("Page already exsists")
                text = ""
                return load_page(request,title,"Page Exists")
        
    else:
        return render(request,"encyclopedia/new.html",{
            'form': NewWikiForm()
        })

def to_edit(request,title):
    """ Editing Function """
    
    content = util.get_entry(title)
    if not content: 
        return load_page(request,title)
    else:
        form = EditWikiForm()
        form.fields["textarea"].initial = content
        form.fields["title"].initial = title
        
        
        return render(request,"encyclopedia/edit.html",{
            'title':title,
            'form': form
        })
        
def save_edit(request):

    # Check if method is POST
    if request.method == "POST":
        
        # Get the data the user submitted 
        form = EditWikiForm(request.POST)
        
        # Need to check if form is valid (server-Side)
        if form.is_valid():
            
            # Get the data
            title = form.data['title']
            textarea = form.cleaned_data["textarea"]
            
            textarea = "\n\n"+textarea
            util.save_entry(title, textarea)
            return load_page(request,title)
            
        else:
            load_page(request,"Issue with the update","Form did not update successfully, please try again")
            
def save_form(request,form,title,textarea):
    print("Save entry")
    textarea = "#" + str(title) + " \n\n"+textarea
    util.save_entry(title, textarea)
    return entry(request,title)
    
    
def random_page(request):
    all_entries = util.list_entries()
    idx = len(all_entries)
    random_idx = random.randint(1,idx)-1
    print("allentries: " + str(len(all_entries)))
    print("idx: " + str(idx))
    print("random_idx: " + str(random_idx))
    entry = all_entries[random_idx]
    
    return load_page(request,entry)
    

def load_page(request,title,content=""):
    
    if(content == "Page Exists"):
         text = markdowner.convert("# Page already exists \n There is " + title + " page already.....\n\n" + "Create a new page or [click here to navigate to it](/wiki/"+str(title)+")!")
    else:
        content = util.get_entry(title)
        if content == None:
            print("No Content, show missing message")
            text = markdowner.convert("#"+str(title) + "\n There is no page related to " + str(title) + "....\n\n" + "Please select [Create New Page](/new) to add new entries!")
        else:
            print("Convert content")
            text = markdowner.convert(content)
    
    print("Loading entry..." + " Title: " + title + " Content: " + str(content))

    return render(request, "encyclopedia/entry.html",
        {
            "text": text,
            "title": title
        })
  
class NewWikiForm(forms.Form):
    title = forms.CharField(label = 'Wiki Title',widget=forms.TextInput(attrs={'class' : 'form-control col-md-6 col-lg-6'}),max_length=200, min_length=2)
    textarea = forms.CharField(label = 'Wiki Text', widget=forms.Textarea(attrs={'id' : 'id_textarea', 'rows' : 5,'class':'form-control col-md-6 col-lg-6'}),max_length=2000,min_length=2)
    confirmation = forms.BooleanField(widget=forms.CheckboxInput(attrs={'id' : 'checkbox', 'class':'checkbox', 'color': 'red'}), label= "Please confirm you agree with Wiki's T&C's    " , required=True)
  
class EditWikiForm(forms.Form):
    title = forms.CharField(label = 'Wiki Title',widget=forms.TextInput(attrs={'readonly':'True','class' : 'form-control col-md-6 col-lg-6'}),max_length=200, min_length=2)
    textarea = forms.CharField(label = 'Wiki Text', widget=forms.Textarea(attrs={'id' : 'id_textarea', 'rows' : 5,'class':'form-control col-md-6 col-lg-6'}),max_length=2000,min_length=2)
    confirmation = forms.BooleanField(widget=forms.CheckboxInput(attrs={'id' : 'checkbox', 'class':'checkbox', 'color': 'red'}), label= "Please confirm you agree with Wiki's T&C's    " , required=True)